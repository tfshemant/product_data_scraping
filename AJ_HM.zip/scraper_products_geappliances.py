import json
import os
import random
import re
import time
import requests
from lxml import html
import pandas as pd
import urllib
file_path = r'C:\Users\HemantTank\Desktop\Hemant Tank\use for home depo.xlsx'
def scrape_product_data_geappliances(model_name):
    model_name = str(model_name)
    if not os.path.exists("output_geappliances"):
        os.makedirs("output_geappliances")
    output_directory = os.path.join(os.getcwd(), 'output_geappliances')

    if not os.path.exists("response"):
        os.makedirs("response")
    response_directory = os.path.join(os.getcwd(), 'response')

    if model_name is not None:
        data_dict = {}
        data_dict['model_name'] = model_name
        print(model_name)
        time.sleep(random.uniform(20, 25))
        url = f"https://www.google.com/search?q={model_name}"
        response = ""
        tree = ""
        try:
            response = requests.get(url)
            model_name_file = re.sub(r'[<>:"/\\|?*]', '_', model_name)
            url_l_html = os.path.join(response_directory, f"URL_{model_name_file.replace("/", "_")}.html")
            tree = html.fromstring(response.text)
            with open(url_l_html, "w", encoding="utf-8") as file:
                file.write(response.text)
        except:
            response = ""
            tree = ""
        all_url = []
        try:
            all_url = tree.xpath(f'//div[@id="main"]//div[contains(text(),{model_name})]/parent::h3/parent::div/parent::div/parent::a/@href')
        except:
            try:
                all_url = tree.xpath('//a[contains(@href, "products.geappliances.com")]/@href')
            except:
                all_url = []
        print(all_url)
        for source_url in all_url:
            if "https://products.geappliances.com/appliance/gea-specs" in source_url:
                data_dict['source'] = ""
                try:
                    data_dict['source'] = source_url.split("/url?q=")[1].split("&")[0]
                except:
                    data_dict['source'] = ""
                data_dict['brand'] = "ge appliances"
                print("source", data_dict['source'])

                payload = {}
                headers = {
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'
                }

                response = ""
                tree = ""
                try:
                    response = requests.request("GET", url=data_dict['source'], headers=headers, data=payload)
                    model_name_file = re.sub(r'[<>:"/\\|?*]', '_', model_name)
                    Product_html = os.path.join(response_directory, f"Product{model_name_file.replace("/", "_")}.html")
                    tree = html.fromstring(response.text)
                    with open(Product_html, "w", encoding="utf-8") as file:
                        file.write(response.text)
                except:
                    response = ""
                data_dict['name'] = ""
                try:
                    data_dict['name'] = tree.xpath('string(//div[@id="mainContent"]/div[2]/div[2]/h5/text())')
                    data_dict['name'] = decoded_text = data_dict['name'].encode().decode('unicode_escape')
                except:
                    data_dict['name'] = ""
                print("name",data_dict['name'])
                data_dict['category'] = ""
                if data_dict['name'] != "":
                    if "water heater" in data_dict['name'].lower():
                        data_dict['category'] = "water heater"
                    if "condenser" in data_dict['name'].lower():
                        data_dict['category'] = "HVAC"
                    if "heat pump" in data_dict['name'].lower():
                        data_dict['category'] = "HVAC"
                    if "air handler" in data_dict['name'].lower():
                        data_dict['category'] = "HVAC"
                    if "air condenser" in data_dict['name'].lower():
                        data_dict['category'] = "HVAC"
                    if "refrigerator" in data_dict['name'].lower():
                        data_dict['category'] = "refrigerator"
                    if "freezer" in data_dict['name'].lower():
                        data_dict['category'] = "refrigerator"
                    if "washer" in data_dict['name'].lower():
                        data_dict['category'] = "washer and dryer"
                    if "dryer" in data_dict['name'].lower():
                        data_dict['category'] = "washer and dryer"
                    if "electric range" in data_dict['name'].lower():
                        data_dict['category'] = "stoves & ranges"
                    if "gas range" in data_dict['name'].lower():
                        data_dict['category'] = "stoves & ranges"
                    if "fuel range" in data_dict['name'].lower():
                        data_dict['category'] = "stoves & ranges"

                print("category", data_dict['category'])
                data_dict['user_manual'] = ""
                try:
                    data_dict['user_manual'] = tree.xpath('string(//img[contains(@alt, "Owner\'s Manual")]/ancestor::a/@href)')
                except:
                    data_dict['user_manual'] = ""
                print("user_manual", data_dict['user_manual'])
                try:
                    if data_dict['user_manual'] != "":
                        pdf_response = requests.get(data_dict['user_manual'])

                        if pdf_response.status_code == 200:
                            model_name_file = re.sub(r'[<>:"/\\|?*]', '_', model_name)
                            model_dir_path = os.path.join(output_directory, model_name_file.replace("/", "_"))
                            if not os.path.exists(model_dir_path):
                                os.makedirs(model_dir_path)
                            pdf_filename = os.path.join(model_dir_path, f"{model_name_file.replace("/", "_")}user_manual_EN.pdf")
                            with open(pdf_filename, 'wb') as f:
                                f.write(pdf_response.content)
                except Exception as e:
                    print(f"error in user_manual {e}")
                data_dict['image_url'] = ""
                try:
                    data_dict['image_url'] = tree.xpath("string(//div[@id='mainContent']/div[2]/div/img/@src)")
                except:
                    data_dict['image_url'] = ""
                print("image", data_dict['image_url'])
                try:
                    if data_dict['image_url']:
                        image_response = requests.get(data_dict['image_url'])

                        if image_response.status_code == 200:
                            model_name_file = re.sub(r'[<>:"/\\|?*]', '_', model_name)
                            model_dir_path = os.path.join(output_directory, model_name_file.replace("/", "_"))
                            if not os.path.exists(model_dir_path):
                                os.makedirs(model_dir_path)
                            image_filename = os.path.join(model_dir_path, f"{model_name_file.replace("/", "_")}_image.jpg")
                            
                            with open(image_filename, 'wb') as f:
                                f.write(image_response.content)
                except Exception as e:
                    print(f"error in image_response {e}")
                print("data_dict", data_dict)
                data_dict['Energy_Guide'] = ""
                data_dict['Warranty_Guide'] = ""
                model_name_file = re.sub(r'[<>:"/\\|?*]', '_', model_name)
                model_dir_path = os.path.join(output_directory, model_name_file.replace("/", "_"))
                if not os.path.exists(model_dir_path):
                    os.makedirs(model_dir_path)
                output_data = os.path.join(model_dir_path, f"{model_name_file.replace("/", "_")} output_data.xlsx")
                df = pd.DataFrame([data_dict])
                df.to_excel(output_data, index=False)

                return data_dict
                # break

        return {}
    else:
        return {}
    
# scrape_product_data_geappliances("GP50T06AVR10")